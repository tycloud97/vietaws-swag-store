"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const config = {
    DYNAMODB_ORDERS_TABLE: process.env.DYNAMODB_ORDERS_TABLE ?? 'orders',
};
exports.default = config;
//# sourceMappingURL=config.js.map